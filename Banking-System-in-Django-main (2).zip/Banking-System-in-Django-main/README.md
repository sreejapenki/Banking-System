# Banking-System-in-Django
The Project Bank Account Simulation is developed on Python using Django Web Framework and MySQL database. The web application is protected with SQL. It is designed professionally by implementing all frontend and backend modules.
